
function verificarCorreo() {
    const correoValido = "cliente465@gmail.com";
    const correoIngresado = document.getElementById("correo").value.trim();

    if (correoIngresado === correoValido) {
        window.location.href = "../contraseña/contraseña.html";
    } else {
        document.getElementById("mensaje").textContent =
            "Correo electrónico no autorizado.";
    }
}