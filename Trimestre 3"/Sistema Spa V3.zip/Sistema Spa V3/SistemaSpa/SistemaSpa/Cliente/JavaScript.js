
function verificarCorreo() {
    const correoValido = "cliente465@gmail.com";
    const correoIngresado = document.getElementById("correo").value.trim();

    if (correoIngresado === correoValido) {
        window.location.href = "../contraseña/contraseña.html";
    } else {
        document.getElementById("mensaje").textContent =
            "Correo electrónico no autorizado.";
    }
}
if (restantes <= 0) {

    document.getElementById("mensaje").textContent =
        "🔒 Página bloqueada por 30 minutos.";

    document.getElementById("password").disabled = true;
    document.getElementById("btnEntrar").disabled = true;

    setTimeout(() => {
        intentos = 0;
        document.getElementById("password").disabled = false;
        document.getElementById("btnEntrar").disabled = false;
        document.getElementById("mensaje").textContent ="✅ Puedes intentar nuevamente.";
    }, 10 * 60 * 1000); // 10 minutos en milisegundos
}

