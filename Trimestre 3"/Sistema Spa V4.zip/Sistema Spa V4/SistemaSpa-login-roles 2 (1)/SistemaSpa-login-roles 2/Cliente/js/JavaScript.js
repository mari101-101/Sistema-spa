document.addEventListener("DOMContentLoaded", () => {
    const menuItems = document.querySelectorAll(".sidebar-menu .menu-item");
    const viewSections = document.querySelectorAll(".view-section");
    const goReserveButtons = document.querySelectorAll(".btn-go-reserve");

    // Función para cambiar de pestaña/vista
    function switchView(targetViewId) {
        // Desactivar todas las secciones
        viewSections.forEach(section => {
            section.classList.remove("active");
        });

        // Activar la seleccionada
        const targetSection = document.getElementById(targetViewId);
        if (targetSection) {
            targetSection.classList.add("active");
        }

        // Actualizar el estado activo en el menú lateral
        menuItems.forEach(item => {
            item.classList.remove("active");
            if (item.getAttribute("data-target") === targetViewId) {
                item.classList.add("active");
            }
        });
    }

    // Eventos para el menú lateral
    menuItems.forEach(item => {
        item.addEventListener("click", (e) => {
            const target = item.getAttribute("data-target");
            if (target) {
                e.preventDefault();
                switchView(target);
            }
        });
    });

    // Eventos para los accesos directos (ej: botón "Reservar nueva cita" del banner)
    goReserveButtons.forEach(button => {
        button.addEventListener("click", () => {
            switchView("view-reservar");
        });
    });
});

