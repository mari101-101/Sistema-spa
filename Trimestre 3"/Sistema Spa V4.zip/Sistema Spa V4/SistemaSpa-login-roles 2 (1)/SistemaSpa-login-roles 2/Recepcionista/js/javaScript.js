// ---- Fecha de hoy en el dashboard ----
const fechaHoyEl = document.getElementById("fechaHoy");
if (fechaHoyEl) {
    const hoy = new Date();
    const opciones = { weekday: "long", year: "numeric", month: "long", day: "numeric" };
    fechaHoyEl.textContent = hoy.toLocaleDateString("es-AR", opciones);
}

// ---- Cambio de tabs en el sidebar ----
function cambiarTab(tabId, enlace) {
    // Ocultar todas las secciones
    document.querySelectorAll(".tab-seccion").forEach(s => s.classList.add("oculto"));
    document.querySelectorAll(".tab-seccion.activo").forEach(s => s.classList.remove("activo"));

    // Mostrar la sección elegida
    const seccion = document.getElementById("tab-" + tabId);
    if (seccion) {
        seccion.classList.remove("oculto");
        seccion.classList.add("activo");
    }

    // Marcar el item activo en el sidebar
    document.querySelectorAll(".sidebar li").forEach(li => li.classList.remove("activo"));
    if (enlace) {
        enlace.closest("li").classList.add("activo");
    }

    // Evitar que el enlace navegue
    return false;
}

// ---- Guardar nueva cita ----
function guardarCita() {
    const cliente  = document.getElementById("clienteNombre").value.trim();
    const servicio = document.getElementById("servicioNuevo").value;
    const fecha    = document.getElementById("fechaNueva").value;
    const horario  = document.getElementById("horarioNuevo").value;
    const errorEl  = document.getElementById("errorCita");
    const exitoEl  = document.getElementById("exitoCita");

    errorEl.textContent = "";
    exitoEl.textContent = "";

    if (!cliente) {
        errorEl.textContent = "Por favor ingresá el nombre del cliente.";
        return;
    }
    if (!servicio) {
        errorEl.textContent = "Por favor seleccioná un servicio.";
        return;
    }
    if (!fecha) {
        errorEl.textContent = "Por favor seleccioná una fecha.";
        return;
    }
    if (!horario) {
        errorEl.textContent = "Por favor seleccioná un horario.";
        return;
    }

    exitoEl.textContent = `✅ Cita para ${cliente} registrada con éxito.`;

    // Limpiar el formulario
    document.getElementById("clienteNombre").value = "";
    document.getElementById("servicioNuevo").value = "";
    document.getElementById("fechaNueva").value = "";
    document.getElementById("horarioNuevo").value = "";
}

// ---- Check-in de clientes ----
const checkins = [];

function hacerCheckin() {
    const input     = document.getElementById("clienteCheckin");
    const nombre    = input.value.trim();
    const resultEl  = document.getElementById("resultadoCheckin");
    const listaEl   = document.getElementById("listaCheckin");

    resultEl.textContent = "";

    if (!nombre) {
        resultEl.style.color = "#e53e3e";
        resultEl.textContent = "Por favor ingresá el nombre del cliente.";
        return;
    }

    const hora = new Date().toLocaleTimeString("es-AR", { hour: "2-digit", minute: "2-digit" });
    checkins.unshift({ nombre, hora });

    resultEl.style.color = "#276749";
    resultEl.textContent = `✅ ${nombre} registrado/a a las ${hora} hs.`;
    input.value = "";

    // Renderizar lista de check-ins
    listaEl.innerHTML = "";
    checkins.forEach(c => {
        const item = document.createElement("div");
        item.classList.add("checkin-item");
        item.innerHTML = `<span>👤 ${c.nombre}</span><span class="hora-checkin">🕐 ${c.hora} hs</span>`;
        listaEl.appendChild(item);
    });
}
