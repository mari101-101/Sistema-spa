// ---- Fecha de hoy ----
const fechaHoyEl = document.getElementById("fechaHoy");
if (fechaHoyEl) {
    const hoy = new Date();
    const opciones = { weekday: "long", year: "numeric", month: "long", day: "numeric" };
    fechaHoyEl.textContent = hoy.toLocaleDateString("es-AR", opciones);
}

// ---- Cambio de tabs ----
function cambiarTab(tabId, enlace) {
    document.querySelectorAll(".tab-seccion").forEach(s => {
        s.classList.add("oculto");
        s.classList.remove("activo");
    });

    const seccion = document.getElementById("tab-" + tabId);
    if (seccion) {
        seccion.classList.remove("oculto");
        seccion.classList.add("activo");
    }

    document.querySelectorAll(".sidebar li").forEach(li => li.classList.remove("activo"));
    if (enlace) enlace.closest("li").classList.add("activo");

    return false;
}

// ---- Disponibilidad ----
const disponibilidades = [];

function guardarDisponibilidad() {
    const dia   = document.getElementById("diaSemana").value;
    const desde = document.getElementById("desdeHora").value;
    const hasta = document.getElementById("hastaHora").value;
    const errEl = document.getElementById("errorDisp");
    const okEl  = document.getElementById("exitoDisp");

    errEl.textContent = "";
    okEl.textContent  = "";

    if (!dia)   { errEl.textContent = "Seleccioná un día."; return; }
    if (!desde) { errEl.textContent = "Seleccioná la hora de inicio."; return; }
    if (!hasta) { errEl.textContent = "Seleccioná la hora de fin."; return; }

    // Verificar duplicado
    if (disponibilidades.find(d => d.dia === dia)) {
        errEl.textContent = `Ya registraste disponibilidad para el ${dia}.`;
        return;
    }

    disponibilidades.push({ dia, desde, hasta });
    okEl.textContent = `✅ Disponibilidad del ${dia} guardada.`;

    document.getElementById("diaSemana").value = "";
    document.getElementById("desdeHora").value = "";
    document.getElementById("hastaHora").value = "";

    renderDisponibilidad();
}

function renderDisponibilidad() {
    const lista = document.getElementById("listaDisponibilidad");
    lista.innerHTML = "";

    const orden = ["Lunes","Martes","Miércoles","Jueves","Viernes","Sábado"];
    const ordenados = [...disponibilidades].sort(
        (a, b) => orden.indexOf(a.dia) - orden.indexOf(b.dia)
    );

    ordenados.forEach(d => {
        const item = document.createElement("div");
        item.classList.add("disp-item");
        item.innerHTML = `
            <span class="disp-dia">📅 ${d.dia}</span>
            <span class="disp-horas">🕐 ${d.desde} — ${d.hasta}</span>
        `;
        lista.appendChild(item);
    });
}
