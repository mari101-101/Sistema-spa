function cambiarTab(idTab, elementoClick) {
    // 1. Ocultar todos los bloques de contenido
    const pestañas = document.querySelectorAll('.tab-content');
    pestañas.forEach(tab => {
        tab.classList.remove('vista-activa');
    });

    // 2. Mostrar la pestaña correspondiente al ID
    const pestañaActiva = document.getElementById(idTab);
    if (pestañaActiva) {
        pestañaActiva.classList.add('vista-activa');
    }

    // 3. Remover estado activo de los botones laterales
    const botonesSidebar = document.querySelectorAll('.sidebar li');
    botonesSidebar.forEach(li => {
        li.classList.remove('activo');
    });

    // 4. Activar el botón de la barra lateral actual
    elementoClick.parentElement.classList.add('activo');
}