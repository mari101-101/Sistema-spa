// ---- Elementos ----
const rolSelect  = document.getElementById("rolSelect");
const correoInput = document.getElementById("correo");
const passwordInput = document.getElementById("password");
const btnIngresar = document.getElementById("btnIngresar");
const errorMsg   = document.getElementById("errorMsg");
const togglePass = document.getElementById("togglePass");

// ---- Credenciales por rol ----
const usuarios = {
    cliente: {
        correo: "cliente@gmail.com",
        password: "1234",
        redirect: "../Cliente/index.html"
    },
    empleado: {
        correo: "empleado@gmail.com",
        password: "1234",
        redirect: "../Empleado/empleado.html"
    },
    administrador: {
        correo: "admin@gmail.com",
        password: "1234",
        redirect: "../Admin/admin.html"
    },
    recepcionista: {
        correo: "recepcionista@gmail.com",
        password: "1234",
        redirect: "../Recepcionista/recepcionista.html"
    }
};

// ---- Mostrar/ocultar contraseña ----
togglePass.addEventListener("click", () => {
    const tipo = passwordInput.type === "password" ? "text" : "password";
    passwordInput.type = tipo;
    togglePass.textContent = tipo === "password" ? "👁" : "🙈";
});

// ---- Limpiar error al escribir ----
[correoInput, passwordInput, rolSelect].forEach(el => {
    el.addEventListener("input", () => { errorMsg.textContent = ""; });
});

// ---- Login ----
btnIngresar.addEventListener("click", () => {
    const rol      = rolSelect.value;
    const correo   = correoInput.value.trim();
    const password = passwordInput.value.trim();

    // Validar campos vacíos
    if (!rol) {
        errorMsg.textContent = "Por favor seleccioná un rol.";
        rolSelect.focus();
        return;
    }
    if (!correo) {
        errorMsg.textContent = "Por favor ingresá tu correo.";
        correoInput.focus();
        return;
    }
    if (!password) {
        errorMsg.textContent = "Por favor ingresá tu contraseña.";
        passwordInput.focus();
        return;
    }

    // Validar credenciales
    const usuario = usuarios[rol];
    if (usuario && correo === usuario.correo && password === usuario.password) {
        errorMsg.style.color = "#6bffb8";
        errorMsg.textContent = "✓ Ingresando...";
        setTimeout(() => {
            window.location.href = usuario.redirect;
        }, 600);
    } else {
        errorMsg.style.color = "#ff6b6b";
        errorMsg.textContent = "Correo o contraseña incorrectos para este rol.";
        passwordInput.value = "";
        passwordInput.focus();
    }
});
